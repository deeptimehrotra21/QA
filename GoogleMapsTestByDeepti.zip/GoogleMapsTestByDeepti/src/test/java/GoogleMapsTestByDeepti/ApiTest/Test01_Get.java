
package GoogleMapsTestByDeepti.ApiTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.RestAssured;


public class Test01_Get 
{
	String googleApi="https://maps.googleapis.com/maps/api/distancematrix/json?origins=Seattle&destinations=San+Francisco&key=AIzaSyCv0F-Buor7Fm3P54tzDnSQSju9FgouNHE";
	
	    @BeforeTest
	    public void checkStatusCodeandDisplayResponse()
	    {
	    	System.out.println("Task03. Checking Status Code and displaying api response");
			RestAssured
			.get(googleApi)
			.then().statusCode(200).log().all();
	    }
	    
		@Test
		public void checkingDestinationValue()
		{
		System.out.println("Task04. Checking Destination value");		
		String destination=
		RestAssured
		.given()
		.when()
		.get(googleApi)
		.then().assertThat().extract().path("destination_addresses").toString();
		if (destination.contentEquals("[San Francisco, CA, USA]"))
		{
			System.out.println(destination+"is coming correctly as expected");
		}else
		{
			System.out.println(destination+"is not coming correctly as expected");
		}
		}
		
		@Test
		public void checkingDistanceValue()
		{
		System.out.println("Task04.Checking Distance value");		
		String distance=
		RestAssured
		.given()
		.when()
		.get(googleApi)
		.then().assertThat().extract().path("rows.elements.distance.value").toString();		
	    if (distance.contentEquals("[[1299873]]"))
		{
			System.out.println(distance+"is coming correctly as expected");
		}else
		{
			System.out.println(distance+"is not coming correctly as expected");
		}
		}
		 @AfterTest
		    public void finishTesting()
		    {
		    	System.out.println("*****Testing is finished******");
		    }
}	
